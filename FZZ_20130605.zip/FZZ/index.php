<?php
	$uri .= $_SERVER['HTTP_HOST'];
	header('Location: http://'.$uri.'/FZZ/zoryazilla.php');
	exit;
?>
