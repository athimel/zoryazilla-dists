if(numVersionZoryazilla < "2.0.0" )
      alert("Une nouvelle version de Zoryazilla est disponible\n\nVeuillez mettre l'extension � jour \n(vous pouvez d�sactiver ce messages dans la page de configuration de mountyzilla).");
