FZZ\scripts_200
===============
les scripts de ZZ fusion unique � ZZ

FZZ\scripts_200\FZ
==================
les scripts de ZZ fusion unique � ZZ ici pour d�bug

FZZ\scripts_MZ
==============
les batchs php de chargement et conversion MZ => FZ
les scripts de MZ fusion/trait� pour ZZ fusion

FZZ\scripts_MZ\FZ
=================
les scripts MZ convertis ici pour d�bug

FZZ\scripts_MZ\MZ
=================
les scripts de MZ pure (charg� sans modif)

FZZ\scripts_MZ\ZZ
=================
les scripts de ZZ qui seront fusionn�s avec ceux de MZ dans FZZ\scripts_MZ\FZ