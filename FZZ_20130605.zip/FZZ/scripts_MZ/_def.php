<?php
	$scriptsMZ = "http://mountyzilla.tilk.info/scripts_0.9/";

	chargerScript("libs");
	chargerScript("cdmbot");
	chargerScript("cdmcomp");
	chargerScript("diplo");
	chargerScript("equip");
	chargerScript("idt");
	chargerScript("menu");
	chargerScript("option");
	chargerScript("pjview");
	chargerScript("profil");
	chargerScript("profil_old");
	chargerScript("saccompo");
	chargerScript("tancompo");
	chargerScript("vue");
	chargerScript("news");
	chargerScript("move");
	chargerScript("mission");
	chargerScript("infomonstre");
	chargerScript("attaque");
	chargerScript("ordresgowap");
	chargerScript("equipgowap");
	chargerScript("mouches");
	chargerScript("malus");
	chargerScript("myevent");
	chargerScript("enchant");
	chargerScript("pre-enchant");
	chargerScript("actions");
		
?>