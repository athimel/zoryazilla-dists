<?
#-----------------------------------------------------------------------------------
# les Variables Globales
#-----------------------------------------------------------------------------------
$SQL_SI_hostname = "localhost";
$SQL_SI_username = "zz";
$SQL_SI_password = "";
$SQL_SI_dbName = "zz";

$_FOPEN_EXTERNAL=true;
$WEB_HEBERGEUR="localhost/FZZ";

?>